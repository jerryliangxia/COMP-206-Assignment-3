#!/bin/bash

echo "Web metrics for log file <weblog1.txt>"
echo "===================="

./webmetrics.sh weblog1.txt

echo ""
echo ""
echo "Web metrics for log file <weblog2.txt>"
echo "===================="

./webmetrics.sh weblog2.txt

echo ""
echo ""
echo "Web metrics for log file <weblog3.txt>"
echo "===================="

./webmetrics.sh weblog3.txt

echo ""
echo ""
